﻿Public Class Form1
    Private Sub Form1_Load(sender As Object, e As EventArgs) Handles MyBase.Load

    End Sub

    Private Sub Form2ToolStripMenuItem_Click(sender As Object, e As EventArgs) Handles Form2ToolStripMenuItem.Click
        Dim f2 As New Form2
        f2.MdiParent = Me
        f2.Show()
    End Sub

    Private Sub Form3ToolStripMenuItem_Click(sender As Object, e As EventArgs) Handles Form3ToolStripMenuItem.Click
        Dim f3 As New Form3
        f3.MdiParent = Me
        f3.Show()
    End Sub

    Private Sub NEWToolStripMenuItem_Click(sender As Object, e As EventArgs) Handles NEWToolStripMenuItem.Click

    End Sub
    Public Sub addform(name As String)
        Dim newform As New Form
        newform.Name = name
        newform.Text = name
        newform.MdiParent = Me
        newform.Show()

    End Sub
    Private Sub CreateANewChildToolStripMenuItem_Click(sender As Object, e As EventArgs) Handles CreateANewChildToolStripMenuItem.Click
        addform("new_form")

    End Sub

    Private Sub EXITToolStripMenuItem_Click(sender As Object, e As EventArgs) Handles EXITToolStripMenuItem.Click
        End
    End Sub

    Private Sub CloseTheActiveChildToolStripMenuItem_Click(sender As Object, e As EventArgs) Handles CloseTheActiveChildToolStripMenuItem.Click
        Me.MdiChildren.ToList.ForEach(Sub(f) f.Close())

    End Sub
End Class
