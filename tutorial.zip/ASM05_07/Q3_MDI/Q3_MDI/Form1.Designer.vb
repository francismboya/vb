﻿<Global.Microsoft.VisualBasic.CompilerServices.DesignerGenerated()>
Partial Class Form1
    Inherits System.Windows.Forms.Form

    'Form overrides dispose to clean up the component list.
    <System.Diagnostics.DebuggerNonUserCode()>
    Protected Overrides Sub Dispose(ByVal disposing As Boolean)
        Try
            If disposing AndAlso components IsNot Nothing Then
                components.Dispose()
            End If
        Finally
            MyBase.Dispose(disposing)
        End Try
    End Sub

    'Required by the Windows Form Designer
    Private components As System.ComponentModel.IContainer

    'NOTE: The following procedure is required by the Windows Form Designer
    'It can be modified using the Windows Form Designer.  
    'Do not modify it using the code editor.
    <System.Diagnostics.DebuggerStepThrough()>
    Private Sub InitializeComponent()
        Me.MenuStrip1 = New System.Windows.Forms.MenuStrip()
        Me.NEWToolStripMenuItem = New System.Windows.Forms.ToolStripMenuItem()
        Me.Form2ToolStripMenuItem = New System.Windows.Forms.ToolStripMenuItem()
        Me.Form3ToolStripMenuItem = New System.Windows.Forms.ToolStripMenuItem()
        Me.FILEMENUToolStripMenuItem = New System.Windows.Forms.ToolStripMenuItem()
        Me.CreateANewChildToolStripMenuItem = New System.Windows.Forms.ToolStripMenuItem()
        Me.CloseTheActiveChildToolStripMenuItem = New System.Windows.Forms.ToolStripMenuItem()
        Me.EXITToolStripMenuItem = New System.Windows.Forms.ToolStripMenuItem()
        Me.WINDOWToolStripMenuItem = New System.Windows.Forms.ToolStripMenuItem()
        Me.OPENToolStripMenuItem = New System.Windows.Forms.ToolStripMenuItem()
        Me.MenuStrip1.SuspendLayout()
        Me.SuspendLayout()
        '
        'MenuStrip1
        '
        Me.MenuStrip1.Items.AddRange(New System.Windows.Forms.ToolStripItem() {Me.NEWToolStripMenuItem, Me.FILEMENUToolStripMenuItem, Me.WINDOWToolStripMenuItem})
        Me.MenuStrip1.Location = New System.Drawing.Point(0, 0)
        Me.MenuStrip1.Name = "MenuStrip1"
        Me.MenuStrip1.Size = New System.Drawing.Size(438, 24)
        Me.MenuStrip1.TabIndex = 1
        Me.MenuStrip1.Text = "MenuStrip1"
        '
        'NEWToolStripMenuItem
        '
        Me.NEWToolStripMenuItem.DropDownItems.AddRange(New System.Windows.Forms.ToolStripItem() {Me.Form2ToolStripMenuItem, Me.Form3ToolStripMenuItem})
        Me.NEWToolStripMenuItem.Name = "NEWToolStripMenuItem"
        Me.NEWToolStripMenuItem.Size = New System.Drawing.Size(53, 20)
        Me.NEWToolStripMenuItem.Text = "MENU"
        '
        'Form2ToolStripMenuItem
        '
        Me.Form2ToolStripMenuItem.Name = "Form2ToolStripMenuItem"
        Me.Form2ToolStripMenuItem.Size = New System.Drawing.Size(152, 22)
        Me.Form2ToolStripMenuItem.Text = "Open Form2"
        '
        'Form3ToolStripMenuItem
        '
        Me.Form3ToolStripMenuItem.Name = "Form3ToolStripMenuItem"
        Me.Form3ToolStripMenuItem.Size = New System.Drawing.Size(152, 22)
        Me.Form3ToolStripMenuItem.Text = "Open Form3"
        '
        'FILEMENUToolStripMenuItem
        '
        Me.FILEMENUToolStripMenuItem.DropDownItems.AddRange(New System.Windows.Forms.ToolStripItem() {Me.CreateANewChildToolStripMenuItem, Me.CloseTheActiveChildToolStripMenuItem, Me.EXITToolStripMenuItem})
        Me.FILEMENUToolStripMenuItem.Name = "FILEMENUToolStripMenuItem"
        Me.FILEMENUToolStripMenuItem.Size = New System.Drawing.Size(77, 20)
        Me.FILEMENUToolStripMenuItem.Text = "FILE MENU"
        '
        'CreateANewChildToolStripMenuItem
        '
        Me.CreateANewChildToolStripMenuItem.Name = "CreateANewChildToolStripMenuItem"
        Me.CreateANewChildToolStripMenuItem.Size = New System.Drawing.Size(152, 22)
        Me.CreateANewChildToolStripMenuItem.Text = "NEW"
        '
        'CloseTheActiveChildToolStripMenuItem
        '
        Me.CloseTheActiveChildToolStripMenuItem.Name = "CloseTheActiveChildToolStripMenuItem"
        Me.CloseTheActiveChildToolStripMenuItem.Size = New System.Drawing.Size(152, 22)
        Me.CloseTheActiveChildToolStripMenuItem.Text = "CLOSE"
        '
        'EXITToolStripMenuItem
        '
        Me.EXITToolStripMenuItem.Name = "EXITToolStripMenuItem"
        Me.EXITToolStripMenuItem.Size = New System.Drawing.Size(152, 22)
        Me.EXITToolStripMenuItem.Text = "EXIT"
        '
        'WINDOWToolStripMenuItem
        '
        Me.WINDOWToolStripMenuItem.DropDownItems.AddRange(New System.Windows.Forms.ToolStripItem() {Me.OPENToolStripMenuItem})
        Me.WINDOWToolStripMenuItem.Name = "WINDOWToolStripMenuItem"
        Me.WINDOWToolStripMenuItem.Size = New System.Drawing.Size(70, 20)
        Me.WINDOWToolStripMenuItem.Text = "WINDOW"
        '
        'OPENToolStripMenuItem
        '
        Me.OPENToolStripMenuItem.Name = "OPENToolStripMenuItem"
        Me.OPENToolStripMenuItem.Size = New System.Drawing.Size(152, 22)
        Me.OPENToolStripMenuItem.Text = "OPEN"
        '
        'Form1
        '
        Me.AutoScaleDimensions = New System.Drawing.SizeF(6.0!, 13.0!)
        Me.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font
        Me.ClientSize = New System.Drawing.Size(438, 261)
        Me.Controls.Add(Me.MenuStrip1)
        Me.IsMdiContainer = True
        Me.MainMenuStrip = Me.MenuStrip1
        Me.Name = "Form1"
        Me.Text = "Form1"
        Me.MenuStrip1.ResumeLayout(False)
        Me.MenuStrip1.PerformLayout()
        Me.ResumeLayout(False)
        Me.PerformLayout()

    End Sub

    Friend WithEvents MenuStrip1 As MenuStrip
    Friend WithEvents NEWToolStripMenuItem As ToolStripMenuItem
    Friend WithEvents Form2ToolStripMenuItem As ToolStripMenuItem
    Friend WithEvents Form3ToolStripMenuItem As ToolStripMenuItem
    Friend WithEvents FILEMENUToolStripMenuItem As ToolStripMenuItem
    Friend WithEvents CreateANewChildToolStripMenuItem As ToolStripMenuItem
    Friend WithEvents CloseTheActiveChildToolStripMenuItem As ToolStripMenuItem
    Friend WithEvents EXITToolStripMenuItem As ToolStripMenuItem
    Friend WithEvents WINDOWToolStripMenuItem As ToolStripMenuItem
    Friend WithEvents OPENToolStripMenuItem As ToolStripMenuItem
End Class
